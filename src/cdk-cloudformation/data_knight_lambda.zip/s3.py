"""
Module for calling S3 APIs.
"""
class S3Service:

    def __init__(self):
        pass