"""
Module for calling Macie2 APIs to derive information.
"""
class MacieService:

    def __init__(self):
        pass
