"""
Module for configuring logger for entire lambda function.
"""

class LoggerConfig:

    def __init__(self):
        pass