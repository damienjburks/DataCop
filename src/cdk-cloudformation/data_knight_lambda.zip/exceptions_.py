"""
Module for project based exceptions.
"""